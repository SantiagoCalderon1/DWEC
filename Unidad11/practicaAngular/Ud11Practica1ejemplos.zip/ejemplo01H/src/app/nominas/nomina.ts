export class Nomina {
    constructor(
        public numero: number,
        public fecha: string,
        public bruto: number,
        public retencion: number
    ) { }
}
