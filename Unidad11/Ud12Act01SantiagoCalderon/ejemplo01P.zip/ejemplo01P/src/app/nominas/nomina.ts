export class Nomina {
    constructor(
        public id: number,
        public nombre: string,
        public fecha: string,
        public bruto: number,
        public retencion: number
    ) { }
}
