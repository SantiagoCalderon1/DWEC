export class Comment {
    constructor(
        public id: number,
        public nombre: string,
        public email: string,
        public mensaje: string
    ) { }
}