<link href="{{ asset('/css/datatables.min.css') }}" rel="stylesheet">
<script src="{!! asset('/js/jquery-3.7.1.min.js') !!}"></script>
<script src="{!! asset('/js/datatables.min.js') !!}"></script>
