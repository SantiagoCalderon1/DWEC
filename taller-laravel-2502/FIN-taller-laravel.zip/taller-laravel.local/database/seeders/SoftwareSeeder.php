<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use DB;
use Carbon\Carbon;
use Str;

class SoftwareSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($conta = 0; $conta < 10; $conta++) {
            DB::table('softwares')->insert([
                'descripcion' => Str::random(45),
                'idmarca' => random_int(1, 6),
                'modelo' => Str::random(10),
                'tpsoft' => Str::random(10),
                'numserie' => Str::random(15),
                'licencia' => Str::random(25),
                'observaciones' => Str::random(150),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
            ]);
        }
    }
}
