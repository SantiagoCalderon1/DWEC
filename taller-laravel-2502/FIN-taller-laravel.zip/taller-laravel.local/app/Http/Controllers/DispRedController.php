<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreDispRedRequest;
use App\Http\Requests\UpdateDispRedRequest;
use App\Models\DispRed;

class DispRedController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDispRedRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DispRed $dispRed)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DispRed $dispRed)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDispRedRequest $request, DispRed $dispRed)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DispRed $dispRed)
    {
        //
    }
}
