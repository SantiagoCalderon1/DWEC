<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreImpresoraRequest;
use App\Http\Requests\UpdateImpresoraRequest;
use App\Models\Impresora;

class ImpresoraController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreImpresoraRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Impresora $impresora)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Impresora $impresora)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateImpresoraRequest $request, Impresora $impresora)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Impresora $impresora)
    {
        //
    }
}
