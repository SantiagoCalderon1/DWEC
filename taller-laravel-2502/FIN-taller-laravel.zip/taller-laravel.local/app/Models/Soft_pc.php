<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Soft_pc extends Model
{
    protected $fillable = ['idpc', 'idsoft', 'fechainst'];
}
