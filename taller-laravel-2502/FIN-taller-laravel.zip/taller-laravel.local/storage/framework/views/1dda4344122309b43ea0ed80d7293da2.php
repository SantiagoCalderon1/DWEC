<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center mt-3">
        <div class="card col-lg-8">
            <div class="card-header d-inline-flex justify-content-between">
                <h2>Nuevo Software</h2>
                <div class="navbar-text">
                    <a href="<?php echo e(route('softwares.index')); ?>" class="btn btn-primary text-white"><i class="fa fa-arrow-left"></i> Volver</a>
                </div>
            </div>
            <div class="card-body">
                <?php echo $__env->make('layouts.errores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form method="POST" action="<?php echo e(route('softwares.store')); ?>" accept-charset="UTF-8">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('software.fieldsform', ['items'=> 'create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <input name="grabar" id="grabar" class="btn btn-primary btn-sm mt-3" type="submit" value="Grabar">
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/taller-laravel.local/resources/views/software/create.blade.php ENDPATH**/ ?>