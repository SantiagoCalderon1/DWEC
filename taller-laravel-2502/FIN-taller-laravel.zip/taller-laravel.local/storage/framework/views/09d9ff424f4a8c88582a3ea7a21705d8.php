<?php if(count($errors)>0): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Errores:</strong>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <p><strong>¡Correcto! :</strong> <?php echo e(Session::get('success')); ?></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php if(Session::has('info')): ?>
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <p><strong>¡Aviso! :</strong> <?php echo e(Session::get('info')); ?></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php if(Session::has('warning')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <p><strong>¡Atención! :</strong> <?php echo e(Session::get('warning')); ?></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php if(Session::has('danger')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <p><strong>¡Error! :</strong> <?php echo e(Session::get('danger')); ?></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if($message = Session::get('mensaje')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <p><strong><?php echo e($message); ?></strong></p>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/html/taller-laravel.local/resources/views/layouts/errores.blade.php ENDPATH**/ ?>