<link href="<?php echo e(asset('/css/datatables.min.css')); ?>" rel="stylesheet">
<script src="<?php echo asset('/js/jquery-3.7.1.min.js'); ?>"></script>
<script src="<?php echo asset('/js/datatables.min.js'); ?>"></script>
<?php /**PATH /var/www/html/taller-laravel.local/resources/views/layouts/datatables.blade.php ENDPATH**/ ?>