<div class="form-group">
    <label for="nombre">Ubicación:</label>
    <?php if($items == 'create'): ?>
        <input id="nombre" class="form-control" placeholder="Introduce la ubicación" maxlength="50" name="nombre" type="text">
    <?php elseif($items == 'edit'): ?>
        <input id="nombre" class="form-control" placeholder="Introduce la ubicación" maxlength="50" name="nombre" type="text" value="<?php echo e(old('nombre', $ubicacion->nombre)); ?>">
    <?php else: ?>
        <input id="nombre" class="form-control" name="nombre" type="text" value="<?php echo e(old('nombre', $ubicacion->nombre)); ?>" disabled readonly>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/taller-laravel.local/resources/views/ubicacion/fieldsform.blade.php ENDPATH**/ ?>