<?php if($items == 'create'): ?>
    <div class="d-flex p-2">
        <div class="form-group col-md-4">
            <label for="numero">Número PC:</label>
            <select class="form-control" id="idpc" name="idpc" required>
                <option value="">Seleccione un PC</option>
                <?php $__currentLoopData = $ordenadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordenador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ordenador->id); ?>"> <?php echo e($ordenador->numero); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-4">
            <label for="marca">Marca PC:</label>
            <input id="marca" class="form-control ms-2" name="marca" type="text" readonly>
        </div>
        <div class="form-group col-md-4">
            <label for="ubicacion">Ubicación:</label>
            <input id="ubicacion" class="form-control ms-3" name="ubicacion" type="text" readonly>
        </div>
    </div>
    <div class="d-flex p-2">
        <div class="form-group col-md-5">
            <label for="software">Software:</label>
            <select class="form-control" id="idsoft" name="idsoft" required>
                <option value="">Seleccione un Software</option>
                <?php $__currentLoopData = $softwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $software): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($software->id); ?>"> <?php echo e($software->descripcion); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-4 ms-2">
            <label for="licencia">Licencia:</label>
            <input id="licencia" class="form-control" name="licencia" type="text" readonly>
        </div>
        <div class="form-group col-md-3 ms-2">
            <label for="fechainst">Fecha de Instalación:</label>
            <input id="fechainst" class="form-control" value="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>" name="fechainst" type="date" required>
        </div>
    </div>
<?php elseif($items == 'edit'): ?>
    <div class="d-flex p-2">
        <div class="form-group col-md-4">
            <label for="numero">Número:</label>
            <select class="form-control" id="idpc" name="idpc" required>
                <?php $__currentLoopData = $ordenadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ordenador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($ordenador->id == $soft_pc->idpc): ?>
                        <option value="<?php echo e($ordenador->id); ?>" selected> <?php echo e($ordenador->numero); ?> </option>
                    <?php else: ?>
                        <option value="<?php echo e($ordenador->id); ?>"> <?php echo e($ordenador->numero); ?> </option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-4 ms-2">
            <label for="marca">Marca PC:</label>
            <input id="marca" class="form-control ms-2" name="marca" type="text" readonly>
        </div>
        <div class="form-group col-md-4 ms-2">
            <label for="ubicacion">Ubicación:</label>
            <input id="ubicacion" class="form-control ms-3" name="ubicacion" type="text" readonly>
        </div>
    </div>
    <div class="d-flex p-2">
        <div class="form-group col-md-5">
            <label for="software">Software:</label>
            <select class="form-control" id="idsoft" name="idsoft" required>
                <?php $__currentLoopData = $softwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $software): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($soft_pc->idsoftware == $software->id): ?>
                        <option value="<?php echo e($software->id); ?>" selected> <?php echo e($software->descripcion); ?> </option>
                    <?php else: ?>
                        <option value="<?php echo e($software->id); ?>"> <?php echo e($software->descripcion); ?> </option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-4 ms-2">
            <label for="modelo">Licencia:</label>
            <input id="licencia" class="form-control" name="licencia" type="text" readonly>
        </div>
        <div class="form-group col-md-3 ms-2">
            <label for="fechainst">Fecha de Instalación:</label>
            <input id="fechainst" class="form-control" value="<?php echo e(old('fechainst', $soft_pc->fechainst)); ?>" name="fechainst" type="date" required>
        </div>
    </div>
<?php elseif($items == 'createubic'): ?>
    <div class="d-flex p-2">
        <div class="form-group col-md-6">
            <label for="ubicacion">Ubicación:</label>
            <select class="form-control" id="idubicacion" name="idubicacion" required>
                <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ubicacion->id); ?>"> <?php echo e($ubicacion->nombre); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="d-flex p-2">
        <div class="form-group col-md-9">
            <label for="software">Software:</label>
            <select class="form-control" id="idsoft" name="idsoft" required>
                <?php $__currentLoopData = $softwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $software): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($software->id); ?>"> <?php echo e($software->descripcion); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-3 ms-2">
            <label for="fechainst">Fecha de Instalación:</label>
            <input id="fechainst" class="form-control" value="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>" name="fechainst" type="date" required>
        </div>
    </div>
<?php else: ?>
    <div class="d-flex p-2">
        <div class="form-group col-md-4">
            <label for="numero">Número PC:</label>
            <input id="numero" class="form-control" name="numero" type="text" value="<?php echo e($ordenador); ?>" readonly>
        </div>
        <div class="form-group col-md-4 ms-2">
            <label for="marca">Marca PC:</label>
            <input id="marca" class="form-control" name="marca" type="text" value="<?php echo e($marca); ?>" readonly>
        </div>
        <div class="form-group col-md-4 ms-2">
            <label for="ubicacion">Ubicacion:</label>
            <input id="ubicacion" class="form-control" name="ubicacion" type="text" value="<?php echo e($ubicacion); ?>" readonly>
        </div>
    </div>
    <div class="d-flex p-2">
        <div class="form-group col-md-5">
            <label for="software">Software:</label>
            <input id="software" class="form-control" name="software" type="text" value="<?php echo e($software); ?>" readonly>
        </div>
        <div class="form-group col-md-4 ms-2">
            <label for="licencia">Licencia:</label>
            <input id="licencia" class="form-control" name="licencia" type="text" value="<?php echo e($licencia); ?>" readonly>
        </div>
        <div class="form-group col-md-3 ms-2">
            <label for="fechainst">Fecha de instalación:</label>
            <input id="fechainst" class="form-control" name="fechainst" type="text" value="<?php echo e($soft_pc->fechainst); ?>" readonly>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/html/taller-laravel.local/resources/views/soft_pc/fieldsform.blade.php ENDPATH**/ ?>