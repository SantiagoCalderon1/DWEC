<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <div class="card col-lg-10">
                <div class="card-header d-inline-flex justify-content-between">
                    <h2>Relación de PCs con software instalado</h2>
                    <div class="navbar-text">
                        <a href="<?php echo e(route('soft_pcs.create')); ?>" class="btn btn-primary text-white"><i class="fa fa-plus"></i>
                            Nuevo Software</a>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary text-white ms-1"><i class="fa fa-arrow-left"></i>
                            Volver</a>
                    </div>
                </div>

                <div class="card-body">
                    <?php echo $__env->make('layouts.errores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if($soft_pcs->isEmpty()): ?>
                        <div>
                            <h3>No hay Softwares</h3>
                        </div>
                    <?php else: ?>
                        <table class="table table-striped">
                            <tr>
                                <th>Acciones</th>
                                <th>Núm. PC</th>
                                <th>Marca</th>
                                <th>Ubicación</th>
                                <th>Software</th>
                                <th>Tipo</th>
                                <th>Fecha Ins</th>
                            </tr>
                            <?php $__currentLoopData = $soft_pcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soft_pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="soft_pcs/<?php echo e($soft_pc->id); ?>/edit" class="btn btn-sm btn-warning me-1"><i
                                                class="fa fa-edit"></i> Modif.</a>
                                        <a href="soft_pcs/<?php echo e($soft_pc->id); ?>" class="btn btn-sm btn-danger"><i
                                                class="fa fa-times"></i> Borrar</a>
                                    </td>
                                    <td><?php echo e($soft_pc->numpc); ?></td>
                                    <td><?php echo e($soft_pc->marca); ?></td>
                                    <td><?php echo e($soft_pc->ubicacion); ?></td>
                                    <td><?php echo e($soft_pc->descripcion); ?></td>
                                    <td><?php echo e($soft_pc->tpsoft); ?></td>
                                    <td><?php echo e($soft_pc->fechainst); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                        <?php echo e($soft_pcs->links()); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/taller-laravel.local/resources/views/soft_pc/lista.blade.php ENDPATH**/ ?>