<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<?php $__env->startSection('hayconfirmaciones'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/jquery-confirm.min.css')); ?>">
    <script src="<?php echo e(asset('/js/jquery-confirm.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center mt-3">
        <div class="card col-lg-12">
            <div class="card-header d-inline-flex justify-content-between">
                <h2>Relación de Activos</h2>
                <div class="navbar-text">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary ms-1 text-white"><i class="fa fa-arrow-left"></i> Volver</a>
                </div>
            </div>
            <div class="card-body">
                <?php echo $__env->make('layouts.errores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if($activos->isEmpty()): ?>
                    <div><h3>No hay Activos para mostrar</h3></div>
                <?php else: ?>
                    <table class="table table-striped">
                        <tr>
                            <th>Acciones</th>
                            <th>Activo</th>
                            <th>Número</th>
                            <th>Marca</th>
                            <th>Modelo</th>
                            <th>Ubicación</th>

                        </tr>
                        <?php $__currentLoopData = $activos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="#" class="btn btn-sm btn-warning" onclick="cambiaubicacion(<?php echo e($activo->id); ?>,'<?php echo e($activo->activo); ?>','<?php echo e($activo->ubicacion); ?>',this)"><i class="fa fa-edit"></i> Cambiar ubic.</a>
                            </td>
                            <td><?php echo e($activo->activo); ?></td>
                            <td><?php echo e($activo->numero); ?></td>
                            <td><?php echo e($activo->marca); ?></td>
                            <td><?php echo e($activo->modelo); ?></td>
                            <td><?php echo e($activo->ubicacion); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php echo e($activos->links()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
function cambiaubicacion(id,activo,ubicacion,obj){
    // alert("Hola "+id+" "+activo+" "+ubicacion);
    // alert($(obj).parent().next().next().next().next().next().html());
    var html = '<div class="d-flex p-2">';
    html += '<div class="form-group col-md-10">';
    html += '<label for="ubicacionact">Ubicación actual:</label>';
    html += '<input id="ubicacionact" class="form-control" readonly name="ubicacionact" type="text" value="'+ubicacion+'">';
    html += '</div></div>';
    html += '<div class="d-flex p-2">';
    html += '<div class="form-group col-md-10">';
    html += '<label for="nuevubicacion">Ubicación nueva:</label>';
    html += '<select class="form-control" id="nuevubicacion" name="nuevubicacion" required>';
    html += '<option value="">Elige nueva ubicación</option>';
    html += '<?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>';
    html += '<option value="<?php echo e($ubicacion->id); ?>"> <?php echo e($ubicacion->nombre); ?> </option>';
    html += '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>';
    html += '/select>';
    html += '</div></div>';

    $.confirm({
        title: 'Cambiar Ubicación',
        content: html,
        buttons: {
            confirmar: function () {
                texto = "";
                var nuevaubicacion=$('#nuevubicacion option:selected').text();
                error = ($('#nuevubicacion').val()=='');
                if (error){
                    texto ="Tienes que seleccionar una nueva ubicación"
                }else{
                    error = (nuevaubicacion==ubicacion);
                    if (error){
                        texto="Tienes que elegir una ubicación distinta a la actual"
                    }
                };
                if (error){
                    $.alert({
                        title: '',
                        content: texto,
                        buttons:{
                            aceptar: {
                                text: 'Aceptar'
                            }
                        }
                    });
                }else{
                    $.ajax({
                        url: '<?php echo e(url("/cambiaubicacion")); ?>',
                        type: 'GET',
                        retrieve:true,
                        dataType: "JSON",
                        data: {
                            "id": id,
                            "activo": activo,
                            "ubicacion": $('#nuevubicacion').val()
                        },
                        success: function (result)
                        {
                            if (result.resultado == 'bien'){
                                $(obj).parent().next().next().next().next().next().html(nuevaubicacion)
                            }
                            $.alert({
                                title: '',
                                content: result.msjrespuesta,
                                buttons:{
                                    aceptar: {
                                        text: 'Aceptar'
                                    }
                                }
                            });
                        }
                    });
                }
            },
            cancelar: function () {
                $.alert({
                    title: '',
                    content: 'Cambio cancelado',
                    buttons:{
                        aceptar: {
                            text: 'Aceptar'
                        }
                    }
                });
    }
        }
    });

}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/taller-laravel.local/resources/views/ubicacion/listaactivos.blade.php ENDPATH**/ ?>