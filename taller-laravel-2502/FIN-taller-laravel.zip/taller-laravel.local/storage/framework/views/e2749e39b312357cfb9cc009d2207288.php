<div class="form-group">
    <label for="nombre">Marca:</label>
    <?php if($items == 'create'): ?>
        <input id="nombre" class="form-control" placeholder="Introduce la marca" maxlength="50" name="nombre" type="text">
    <?php elseif($items == 'edit'): ?>
        <input id="nombre" class="form-control" placeholder="Introduce la marca" maxlength="50" name="nombre" type="text" value="<?php echo e(old('nombre', $marca->nombre)); ?>">
    <?php else: ?>
        <input id="nombre" class="form-control" name="nombre" type="text" value="<?php echo e(old('nombre', $marca->nombre)); ?>" disabled readonly>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/taller-laravel.local/resources/views/marca/fieldsform.blade.php ENDPATH**/ ?>