<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <div class="card col-lg-10">
                <div class="card-header d-inline-flex justify-content-between">
                    <h2>Relación de Softwares</h2>
                    <div class="navbar-text">
                        <a href="<?php echo e(route('softwares.create')); ?>" class="btn btn-primary text-white"><i class="fa fa-plus"></i>
                            Nuevo Software</a>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary text-white ms-1"><i class="fa fa-arrow-left"></i>
                            Volver</a>
                    </div>
                </div>

                <div class="card-body">
                    <?php echo $__env->make('layouts.errores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if($softwares->isEmpty()): ?>
                        <div>
                            <h3>No hay Softwares</h3>
                        </div>
                    <?php else: ?>
                        <table class="table table-striped">
                            <tr>
                                <th>Acciones</th>
                                <th>Descripción</th>
                                <th>Licencia</th>
                            </tr>
                            <?php $__currentLoopData = $softwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $software): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="softwares/<?php echo e($software->id); ?>" class="btn btn-sm btn-primary me-1"><i class="fa fa-eye"></i> Ver</a>
                                        <a href="softwares/<?php echo e($software->id); ?>/edit" class="btn btn-sm btn-warning me-1"><i
                                                class="fa fa-edit"></i> Modif.</a>
                                        <a href="softwares/showdelete/<?php echo e($software->id); ?>" id="<?php echo e($software->id); ?>" class="btn btn-sm btn-danger"><i class="fa fa-times"></i> Borrar</a>
                                    </td>
                                    <td><?php echo e($software->descripcion); ?></td>
                                    <td><?php echo e($software->licencia); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                        <?php echo e($softwares->links()); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/taller-laravel.local/resources/views/software/lista.blade.php ENDPATH**/ ?>