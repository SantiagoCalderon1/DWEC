<?php $__env->startSection('haydatatables'); ?>
    <?php echo $__env->make('layouts.datatables', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center mt-3">
            <div class="card col-lg-8">
                <div class="card-header d-inline-flex justify-content-between">
                    <h2>Relación de Ubicaciones</h2>
                    <div class="navbar-text">
                        <a href="<?php echo e(route('ubicacions.create')); ?>" class="btn btn-primary text-white"><i class="fa fa-plus"></i> Nueva Ubicación</a>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary text-white ms-1"><i class="fa fa-arrow-left"></i>
                            Volver</a>
                    </div>
                </div>

                <div class="card-body">
                    <?php echo $__env->make('layouts.errores', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php if($ubicacions->isEmpty()): ?>
                        <div>
                            <h3>No hay Ubicaciones</h3>
                        </div>
                    <?php else: ?>
                        <table class="table table-striped mitabladedatos">
                            <thead>
                                <tr>
                                    <th>Acciones</th>
                                    <th>ID</th>
                                    <th>Ubicación</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                        <?php echo e($ubicacions->links()); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(function () {
            var $input = $("input[name='keyword']"), $context = $(".keyword");
            $input.on("input", function () {
                var term = $(this).val();
                $context.show().unmark();
                if (term) {
                    $context.mark(term, {
                        done: function () {
                            $context.not(":has(mark)").hide();
                        }
                    });
                }
            });

            $('.mitabladedatos').DataTable({
                dom: 'Blfrtip',
                processing: true,
                serverSide: true,
                pageLength: 10,
                order: [ 1, "asc" ],
                lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "Todos"]],
                ajax: '<?php echo e(url("/ubicacions")); ?>',
                language:{
                    lengthMenu:"Mostrar _MENU_ registros por página. ",
                    zeroRecords: "Lo sentimos. No se encontraron registros.",
                    info: "Mostrando página _PAGE_ de _PAGES_",
                    infoEmpty: "No hay registros aún.",
                    infoFiltered: "(filtrados de un total de _MAX_ registros)",
                    search : "Búsqueda",
                    LoadingRecords: "Cargando ...",
                    Processing: "Procesando...",
                    SearchPlaceholder: "Comience a teclear...",
                    paginate: {
                        previous: "Anterior",
                        next: "Siguiente",
                        first: "Primero",
                        last: "Último",
                    },

                },
                columns: [
                    {data: 'action', name: 'action', orderable: false, searchable: false},
                    {data: 'id', name: 'id'},
                    {data: 'ubicacion', name: 'ubicacion'},
                ],
                columnDefs: [ { width: '30%', targets: 0 } ],
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/taller-laravel.local/resources/views/ubicacion/lista.blade.php ENDPATH**/ ?>